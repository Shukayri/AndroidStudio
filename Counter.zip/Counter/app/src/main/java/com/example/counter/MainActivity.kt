package com.example.counter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    var id = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val value = findViewById<TextView>(R.id.value)
        value.text = "" + id
        val plus = findViewById<Button>(R.id.plus)
        var minus =  findViewById<Button>(R.id.minus)

        plus.setOnClickListener {
            value.text = ""+ ++id
        }
        minus.setOnClickListener {
            value.text = ""+ --id
        }
    }
}
package com.example.edittest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import java.lang.Math.random
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //val button = findViewById<Button>(R.id.button)
        //val textView = findViewById<TextView>(R.id.textView)
        val topLeftButton = findViewById<Button>(R.id.button4)
        val topLeftTextVie = findViewById<TextView>(R.id.textView7)
        val topRightButton = findViewById<Button>(R.id.button3)
        val topRightTextVie = findViewById<TextView>(R.id.textView8)
        val downMiddleButton = findViewById<Button>(R.id.button5)
        val downMiddleTextView = findViewById<TextView>(R.id.textView9)


        topLeftButton.setOnClickListener {
            topLeftTextVie.text = "Hello World"

        }
        //val ran = Random.nextInt()
        fun operation(): Int {
            val num1 = Random.nextInt(20)
            val num2 = Random.nextInt(20)
            val sum = num1 + num2
            topRightTextVie.text = "$num1 + $num2 = $sum"
            return sum
        }
        topRightButton.setOnClickListener {

            //topRightTextVie.text = "$"
            //fun sendMessage(view: View){
                operation()

            //}

        }
        fun multiply(): Int{
            val num1 = Random.nextInt(10)
            val num2 = Random.nextInt(10)
            val sum = num1 * num2
            downMiddleTextView.text = "$num1 * $num2 = $sum"
            return sum
        }
        downMiddleButton.setOnClickListener {
            multiply()
        }


        //button.setOnClickListener {
         //   textView.text = "fff"
       // }
    }
}